<script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/tether.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="<?php echo e(asset('assets/js/jquery.slimscroll.js')); ?>"></script>
<!--Wave Effects -->
<script src="<?php echo e(asset('assets/js/waves.js')); ?>"></script>
<!--Menu sidebar -->
<script src="<?php echo e(asset('assets/js/sidebarmenu.js')); ?>"></script>
<!--stickey kit -->
<script src="<?php echo e(asset('assets/plugins/sticky-kit-master/dist/sticky-kit.min.js')); ?>"></script>
<!--Custom JavaScript -->
<script src="<?php echo e(asset('assets/js/custom.min.js')); ?>"></script>
<!-- ============================================================== -->
<!-- This page plugins -->
<!-- ============================================================== -->
<!-- chartist chart -->
<script src="<?php echo e(asset('assets/plugins/chartist-js/dist/chartist.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js')); ?>"></script>
<!-- Chart JS -->
<script src="<?php echo e(asset('assets/plugins/echarts/echarts-all.js')); ?>"></script>
<!-- Chart JS -->
<script src="<?php echo e(asset('assets/js/dashboard1.js')); ?>"></script>
<!-- ============================================================== -->
<!-- Style switcher -->
<!-- ============================================================== -->
<script src="<?php echo e(asset('assets/plugins/styleswitcher/jQuery.style.switcher.js')); ?>"></script>

<script>
    (function(i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function() {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o), m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', '../../../../../www.google-analytics.com/analytics.js', 'ga');
    ga('create', 'UA-85622565-1', 'auto');
    ga('send', 'pageview');
</script>

<?php echo $__env->yieldContent('script'); ?>
<?php /**PATH E:\xampp\htdocs\Taxi-management\resources\views/layouts/script.blade.php ENDPATH**/ ?>