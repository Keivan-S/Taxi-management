<footer class="footer">
    © 2017 Monster Admin by wrappixel.com
</footer>
<?php /**PATH E:\xampp\htdocs\Taxi-management\resources\views/layouts/footer.blade.php ENDPATH**/ ?>