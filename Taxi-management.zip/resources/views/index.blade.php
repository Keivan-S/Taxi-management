@extends('layouts.master')

@section('title')
    Dashboard
@endsection


@section('content')
    @include('layouts.content')
@endsection
